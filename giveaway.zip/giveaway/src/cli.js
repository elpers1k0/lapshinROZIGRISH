const readline = require('readline');
const loader = require('./loader');
const logger = require('./logger');
const roulette = require('./roulette');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function showMenu() {
    console.log('\n--- Система для розыгрыша призов ---');
    console.log('1. Запустить розыгрыш (из JSON)');
    console.log('2. Посмотреть историю');
    console.log('3. Выход');
    
    rl.question('Выберите действие (1-3): ', (answer) => {
        handleCommand(answer.trim());
    });
}

function handleCommand(command) {
    switch (command) {
        case '1':
            runDraw('participants.json');
            break;
        case '2':
            showHistory();
            break;
        case '3':
            console.log('До свидания!');
            rl.close();
            break;
        default:
            console.log('Неверная команда. Пожалуйста, введите число от 1 до 3.');
            showMenu();
            break;
    }
}

function runDraw(filename) {
    try {
        const participants = loader.loadParticipants(filename);
        
        if (participants.length === 0) {
            console.log('Список участников пуст.');
            return showMenu();
        }
        
        console.log(`Успешно загружено ${participants.length} участников.`);
        
        roulette.animateWheel(() => {
            const winner = roulette.pickWinner(participants);
            
            console.log('\n!!! ПОБЕДИТЕЛЬ ВЫБРАН !!!');
            console.log(`Имя: ${winner.name}`);
            console.log(`Контакт: ${winner.contact}\n`);
            
            logger.saveHistory(participants, winner);
            
            showMenu();
        });
        
    } catch (error) {
        console.log(`Ошибка: ${error.message}`);
        showMenu();
    }
}

function showHistory() {
    const history = logger.getHistory();
    
    if (history.length === 0) {
        console.log('История розыгрышей пуста.');
    } else {
        console.log('\n--- История розыгрышей ---');
        history.forEach((record, index) => {
            console.log(`${index + 1}. [${record.date} ${record.time}] Участников: ${record.participantsCount}. Победитель: ${record.winner.name}`);
        });
        console.log('--------------------------');
    }
    
    showMenu();
}

function start() {
    showMenu();
}

module.exports = {
    start
};
