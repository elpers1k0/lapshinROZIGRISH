function animateWheel(callback) {
    const frames = ['◉', '◐', '●', '◑'];
    let i = 0;
    let cycles = 0;
    const maxCycles = 20;
    
    const interval = setInterval(() => {
        process.stdout.write(`\rВращаем колесо... ${frames[i]}`);
        i = (i + 1) % frames.length;
        cycles++;
        
        if (cycles >= maxCycles) {
            clearInterval(interval);
            process.stdout.write('\n');
            callback();
        }
    }, 100);
}

function pickWinner(participants) {
    const randomIndex = Math.floor(Math.random() * participants.length);
    return participants[randomIndex];
}

module.exports = {
    animateWheel,
    pickWinner
};
