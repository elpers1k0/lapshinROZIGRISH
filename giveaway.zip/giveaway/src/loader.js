const fs = require('fs');
const path = require('path');

function loadParticipants(filename) {
    const filePath = path.join(__dirname, '..', filename);

    if (!fs.existsSync(filePath)) {
        throw new Error(`Файл ${filename} не найден!`);
    }

    const content = fs.readFileSync(filePath, 'utf8');

    if (filename.endsWith('.json')) {
        try {
            return JSON.parse(content);
        } catch (e) {
            throw new Error(`Ошибка при чтении JSON: ${e.message}`);
        }
    } else {
        throw new Error('Формат файла не поддерживается. Используйте .json');
    }
}

module.exports = {
    loadParticipants
};
