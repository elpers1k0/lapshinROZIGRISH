const fs = require('fs');
const path = require('path');

const historyFile = path.join(__dirname, '..', 'history.json');

function saveHistory(participants, winner) {
    let history = [];
    
    if (fs.existsSync(historyFile)) {
        try {
            const data = fs.readFileSync(historyFile, 'utf8');
            history = JSON.parse(data);
        } catch (e) {
            console.log("Ошибка чтения истории, будет создана новая");
        }
    }

    const record = {
        date: new Date().toLocaleDateString(),
        time: new Date().toLocaleTimeString(),
        participantsCount: participants.length,
        winner: winner
    };

    history.push(record);

    fs.writeFileSync(historyFile, JSON.stringify(history, null, 2), 'utf8');
}

function getHistory() {
    if (!fs.existsSync(historyFile)) {
        return [];
    }
    
    try {
        const data = fs.readFileSync(historyFile, 'utf8');
        return JSON.parse(data);
    } catch (e) {
        return [];
    }
}

module.exports = {
    saveHistory,
    getHistory
};
